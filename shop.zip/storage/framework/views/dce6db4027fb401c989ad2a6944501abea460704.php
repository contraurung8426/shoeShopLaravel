<?php $__env->startSection('productdetail_content'); ?>
    <h1><?php echo e($product->name); ?></h1>
    <div class="content_half float_l">
        <a rel="lightbox[portfolio]" href="source/images/product/<?php echo e($product->image); ?>"><img
                    src="source/images/product/<?php echo e($product->image); ?>" alt="image"/></a>
    </div>
    <div class="content_half float_r">
        <form action="<?php echo e(route('them-gio-hang')); ?>" method="post">
            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
            <input type="hidden" name="id" value="<?php echo e($product->id); ?>">
            <table>
                <tr>
                    <td width="160">Giá gốc:</td>
                    <td><?php echo e($product->unit_price); ?></td>
                </tr>
                <tr>
                    <td>Giá khuyến mãi:</td>
                    <?php if($product->promotion_price>0): ?>
                        <td><?php echo e($product->promotion_price); ?></td>
                    <?php else: ?>
                        <td>Chưa có</td>
                    <?php endif; ?>
                </tr>
                <tr>
                    <td>Tình trạng:</td>
                    <?php if($product->qty==0): ?>
                        <td>Hết hàng</td>
                    <?php else: ?>
                        <td>Còn hàng</td>
                    <?php endif; ?>
                </tr>
                <tr>
                    <td>Thương hiệu:</td>
                    <td><?php echo e($product->brand); ?></td>
                </tr>
                <tr>
                    <td>Số lượng</td>
                    <td><input type="number" name="qty" min="1" max="5" value="1"
                               style="width: 30px; text-align: right"/></td>
                </tr>
            </table>
            <div class="cleaner h20"></div>
            <button class="btn btn-primary" type="submit" style="font-weight: bold;color:#666666;border-radius:3px;">
                Thêm vào giỏ hàng
            </button>
        </form>
    </div>
    <div class="cleaner h30"></div>
    <h5>Thông tin khác về sản phẩm</h5>
    <p><?php echo e($product->description); ?></p>
    <div class="cleaner h50"></div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('related_product_content'); ?>
    <h3>Sản phẩm liên quan</h3>
    <?php $__currentLoopData = $related_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="product_box">
            <h3><?php echo e($value->name); ?></h3>
            <a href="<?php echo e(route('chitiet-sanpham',$value->id)); ?>"><img class="img_product"
                                                                   src="source/images/product/<?php echo e($value->image); ?>"
                                                                   alt="Shoes 1"/></a>
            <?php if($value->promotion_price==0): ?>
                <p class="product_price"><?php echo e(number_format($value->unit_price)); ?>đ</p>
            <?php else: ?>
                <p class="product_old_price"><?php echo e(number_format($value->unit_price)); ?>đ</p>
                <p class="product_new_price"><?php echo e(number_format($value->promotion_price)); ?>đ</p>
            <?php endif; ?>
            <div class="cleaner"></div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shop\resources\views/page/productdetail.blade.php ENDPATH**/ ?>