<?php $__env->startSection('list_type_product_content'); ?>
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="page-header">
                <h2 class="pageheader-title">Danh Sách Loại Sản Phẩm</h2>
                <div class="page-breadcrumb">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item">Loại Sản Phẩm</li>
                            <li class="breadcrumb-item active" aria-current="page">Danh Sách Loại Sản Phẩm</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('admin.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row">
        <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
            <div class="card">
                <h5 class="card-header">Loại Sản Phẩm</h5>
                <div class="card-body">
                    <table class="table table-hover">
                        <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Thao tác</th>
                            <th scope="col">Tên Loại Sản Phẩm</th>
                            <th scope="col">Ghi chú</th>
                            <th scope="col">Trạng Thái</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $typeproduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($value->id); ?></th>
                                <td>
                                    <p><a onclick="return ConfirmDel('Bạn có chắc muốn xóa loại sản phẩm này?')"
                                          href="<?php echo e(route('xoa-loai-sanpham',$value->id)); ?>">Xóa</a></p>
                                    <p><a href="<?php echo e(route('sua-loai-sanpham',$value->id)); ?>">Sửa</a></p>
                                </td>
                                <td><?php echo e($value->name); ?></td>
                                <td><?php echo e($value->note); ?></td>
                                <td><?php echo e($value->status); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shop\resources\views/admin/pageAdmin/list-type-product.blade.php ENDPATH**/ ?>