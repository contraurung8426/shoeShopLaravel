<div class="sidebar_box"><span class="bottom"></span>
    <h3>Sản phẩm bán chạy</h3>
    <div class="content">
        <?php $__currentLoopData = $sp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="bs_box">
                <a href="<?php echo e(route('chitiet-sanpham',$value->id)); ?>"><img class="img_bestseller"
                                                                       src="source/images/product/<?php echo e($value->image); ?>"
                                                                       alt="image"/></a>
                <h4><?php echo e($value->name); ?></h4>
                <?php if($value->promotion_price>0): ?>
                    <p class="product_old_price"><?php echo e(number_format($value->unit_price)); ?>đ</p>
                    <p class="product_new_price"><?php echo e(number_format($value->promotion_price)); ?>đ</p>
                <?php else: ?>
                    <p class="product_price"><?php echo e(number_format($value->unit_price)); ?>đ</p>
                <?php endif; ?>
                <div class="cleaner"></div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div><?php /**PATH C:\xampp\htdocs\shop\resources\views/bestsellers.blade.php ENDPATH**/ ?>