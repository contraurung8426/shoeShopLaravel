<?php $__env->startSection('bill_detail_content'); ?>
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="page-header">
                <h2 class="pageheader-title">Chi Tiết Hóa Đơn</h2>
                <div class="page-breadcrumb">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item">Hóa Đơn</li>
                            <li class="breadcrumb-item active" aria-current="page">Chi Tiết Hóa Đơn</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="table-responsive">
            <table class="table">
                <thead class="bg-light">
                <tr class="border-0">
                    <th class="border-0">#</th>
                    <th class="border-0">Hình ảnh</th>
                    <th class="border-0">Tên sản phẩm</th>
                    <th class="border-0">Số lương mua</th>
                    <th class="border-0">Đơn giá</th>
                </tr>
                </thead>
                <tbody>
                <?php
                $index = 0;
                ?>
                <?php $__currentLoopData = $billdetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    $product = DB::table('products')->where('id', $value->id_product)->first();
                    ?>
                    <tr>
                        <td>
                            <?php
                            $index++;
                            echo $index;
                            ?>
                        </td>
                        <td>
                            <div class="m-r-10"><img src="source/images/product/<?php echo $product->image ?>"
                                                     alt="user"
                                                     class="rounded"
                                                     width="80" height="60"></div>
                        </td>
                        <td><?php echo $product->name ?></td>
                        <td><?php echo e($value->quantity); ?></td>
                        <td><?php echo e($value->unit_price); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shop\resources\views/admin/pageAdmin/bill-detail.blade.php ENDPATH**/ ?>