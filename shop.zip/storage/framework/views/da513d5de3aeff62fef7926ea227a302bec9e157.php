<h2>Chào bạn <?php echo e($name); ?>!!</h2>
Cám ơn bạn đã đăng ký tài khoản Yasuo Shop<br>
Link kích hoạt tài khoản của bạn <a href="http://localhost:8080/shop/public/auth-account/<?php echo e($token); ?>">kích hoạt tài khoản</a><br>
Mong bạn mua được những sản phẩm ưng ý với giá cả phải chăng
<h2>Shop giày Yasuo</h2><?php /**PATH C:\xampp\htdocs\shop\resources\views/mail/active-account.blade.php ENDPATH**/ ?>