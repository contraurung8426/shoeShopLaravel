<?php $__env->startSection('account_content'); ?>
    <h2>Tài Khoản</h2>
    <?php if(count($errors)>0): ?>
        <h4 class="btn-danger">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($err); ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </h4>
    <?php endif; ?>
    <?php if(Session::has('success')): ?>
        <h4 class="btn-success">
            <?php echo e(Session::get('success')); ?>

        </h4>
    <?php endif; ?>
    <h5><strong>THÔNG TIN TÀI KHOẢN</strong></h5>
    <form action="<?php echo e(route('sua-tt-taikhoan')); ?>" method="post">
        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
        <div class="content_half float_l checkout">
            Họ Tên: (*)
            <input type="text" value="<?php echo e(Auth::user()->full_name); ?>" name="name" required style="width:300px;" readonly/>
            <br/>
            <br/>
            ĐIỆN THOẠI (*)<br/>
            <input type="text" value="<?php echo e(Auth::user()->phone_number); ?>" name="phone_number" style="width:300px;" required/>
            <br/>
            <br/>
            Địa chỉ: (*)
            <input type="text" value="<?php echo e(Auth::user()->address); ?>" name="address" required style="width:300px;"/>
            <br/>
            <br/>
            <input type="submit" value="Lưu">
        </div>
    </form>
    <div class="content_half float_r checkout">
        <h5><STRONG>THAO TÁC</STRONG></h5>
        <br/>
        <a href="<?php echo e(route('sua-tt-taikhoan')); ?>">Thay đổi thông tin tài khoản</a>
        <br/>
        <br/>
        <a href="<?php echo e(route('doi-matkhau')); ?>">Đổi mật khẩu</a>
    </div>
    <div class="cleaner h50"></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shop\resources\views/page/edit-account.blade.php ENDPATH**/ ?>