<?php $__env->startSection('list_product_content'); ?>
    <div class="row">
        <div class="table-responsive">
            <table class="table">
                <thead class="bg-light">
                <tr class="border-0">
                    <th class="border-0">#</th>
                    <th class="border-0">Thao tác</th>
                    <th class="border-0">Hình ảnh</th>
                    <th class="border-0">Tên sản phẩm</th>
                    <!-- <th class="border-0">Product Id</th> -->
                    <th class="border-0">Số lượng</th>
                    <th class="border-0">Đơn giá</th>
                    <th class="border-0">Giá khuyến mãi</th>
                    <th class="border-0">Thương hiệu</th>
                    <th class="border-0">Mô tả</th>
                    <th class="border-0">Trạng thái</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <td>1</td>
                    <td>
                        <p><a href="#">Xóa</a></p>
                        <p><a href="#">Sửa</a></p>
                    </td>
                    <td>
                        <div class="m-r-10"><img src="source/images/product/pic1.jpg" alt="user" class="rounded"
                                                 width="80" height="60"></div>
                    </td>
                    <td>Giày Khá Bảnh</td>
                    <!-- <td>id000001 </td> -->
                    <td>20</td>
                    <td>8.000.000</td>
                    <td>7.000.000</td>
                    <td>Gucci</td>
                    <td>Đẹp</td>
                    <td>Mới</td>
                </tr>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shop\resources\views/admin/pageAdmin/list_product.blade.php ENDPATH**/ ?>