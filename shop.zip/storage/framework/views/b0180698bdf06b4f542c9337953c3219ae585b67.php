<?php $__env->startSection('about_content'); ?>
    <h1>Về Chúng Tôi</h1>
    <h2>Yasuo Shoe Shop</h2>
    <p>BXH 5 bài hát Việt Nam trên ZingMp3</p>
    <ul class="tmo_list">
        <li>Đừng Yêu Nữa, Em Mệt Rồi</li>
        <li>Anh Ơi Ở Lại</li>
        <li>Bạc Phận</li>
        <li>Anh Nhà Ở Đâu Thế?</li>
        <li>Một Bước Yêu Vạn Dặm Đau</li>
    </ul>
    <div class="cleaner h20"></div>
    <h3>Tổ Chức Nhóm</h3>
    <p></p>
    <div class="cleaner"></div>
    <blockquote>Khổ trước sướng sau thế mới giàu
        Tình nghĩa anh em có chắc bền lâu
        Giàu trước khổ sau thế mới đau lòng
        Khi sa cơ không còn ai
        Khi mình đã có những gì người ta cần
        Người ta luôn quan tâm và chia sẻ
        Khi mình sa cơ thất thế trên cuộc đời
        Người ta mang mình ra đành rẽ bán
        Khi gian nan mới biết ai là bạn
        Hỏi thế nhân ơi, có mấy người cũng như tôi
    </blockquote>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shop\resources\views/page/about.blade.php ENDPATH**/ ?>