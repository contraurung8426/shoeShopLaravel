<?php $__env->startSection('product_slider'); ?>
    <div id="slider-wrapper">
        <div id="slider" class="nivoSlider">
            <?php $__currentLoopData = $slide; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <img src="source/images/slider/<?php echo e($value->image); ?>" alt=""/>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div id="htmlcaption" class="nivo-html-caption">
            <strong>This</strong> is an example of a <em>HTML</em> caption with <a href="#">a link</a>.
        </div>
    </div>
    <script type="text/javascript" src="source/js//jquery-1.4.3.min.js"></script>
    <script type="text/javascript" src="source/js//jquery.nivo.slider.pack.js"></script>
    <script type="text/javascript">
        $(window).load(function () {
            $('#slider').nivoSlider();
        });
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('product_new_product'); ?>
    <h1>Sản phẩm mới</h1>
    <h4 style="color:blue;">Tìm thấy <?php echo e(count($new_product)); ?> sản phẩm</h4>
    <?php $__currentLoopData = $new_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="product_box">
            <h3><?php echo e($new->name); ?></h3>
            <a href="<?php echo e(route('chitiet-sanpham',$new->id)); ?>"><img class="img_product"
                                                                 src="source/images/product/<?php echo e($new->image); ?>"
                                                                 alt="Shoes 2"/></a>
            <?php if($new->promotion_price==0): ?>
                <p class="product_price"><?php echo e(number_format($new->unit_price)); ?>đ</p>
            <?php else: ?>
                <p class="product_old_price"><?php echo e(number_format($new->unit_price)); ?>đ</p>
                <p class="product_new_price"><?php echo e(number_format($new->promotion_price)); ?>đ</p>
            <?php endif; ?>
            <div class="cleaner"></div>
            <form action="<?php echo e(route('them-gio-hang')); ?>" method="post">
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                <input type="hidden" name="id" value="<?php echo e($new->id); ?>">
                <input type="number" name="qty" min="1" max="5" style="width: 30px;" required>
                <input type="submit" style="font-weight: bold;color:#666666;border-radius:3px;" class="addtocart"
                       value="Thêm vào giỏ hàng">
                
                
            </form>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="row"><?php echo e($new_product->links()); ?></div>
    <div class="cleaner"></div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('product_sale_product'); ?>
    <h1>Sản phẩm khuyến mãi</h1>
    <h4 style="color:blue;">Tìm thấy <?php echo e(count($sale_product)); ?> sản phẩm</h4>
    <?php $__currentLoopData = $sale_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="product_box">
            <h3><?php echo e($sale->name); ?></h3>
            <a href="<?php echo e(route('chitiet-sanpham',$sale->id)); ?>"><img class="img_product"
                                                                  src="source/images/product/<?php echo e($sale->image); ?>"
                                                                  alt="Shoes 2"/></a>
            <p class="product_old_price"><?php echo e(number_format($sale->unit_price)); ?>đ</p>
            <p class="product_new_price"><?php echo e(number_format($sale->promotion_price)); ?>đ</p>
            <div class="cleaner"></div>
            <form action="<?php echo e(route('them-gio-hang')); ?>" method="post">
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                <input type="hidden" name="id" value="<?php echo e($sale->id); ?>">
                <input type="number" name="qty" min="1" max="5" style="width: 30px;" required>
                <input type="submit" style="font-weight: bold;color:#666666;border-radius:3px;" class="addtocart"
                       value="Thêm vào giỏ hàng">
                
                
            </form>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="row"><?php echo e($sale_product->links()); ?></div>
    <div class="cleaner"></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shop\resources\views/page/trangchu.blade.php ENDPATH**/ ?>