<div class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                Đồ án Web 2019. Được thiết kế bởi <a href="#">các thành viên trong nhóm</a>.
            </div>
            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                <div class="text-md-right footer-links d-none d-sm-block">
                    <a href="javascript: void(0);">Về chúng tôi</a>
                    <a href="javascript: void(0);">Hỗ trợ</a>
                    <a href="javascript: void(0);">Liên Hệ</a>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\shop\resources\views/admin/footer.blade.php ENDPATH**/ ?>