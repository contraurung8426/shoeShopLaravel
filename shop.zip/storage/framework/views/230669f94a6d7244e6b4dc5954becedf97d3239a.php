<?php $__env->startSection('search_content'); ?>
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="page-header">
                <h2 class="pageheader-title">Danh Sách Sản Phẩm</h2>
                <div class="page-breadcrumb">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item">Sản Phẩm</li>
                            <li class="breadcrumb-item active" aria-current="page">Danh Sách Sản Phẩm</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="table-responsive">
            <table class="table">
                <thead class="bg-light">
                <tr class="border-0">
                    <th class="border-0">#</th>
                    <th class="border-0">Thao tác</th>
                    <th class="border-0">Hình ảnh</th>
                    <th class="border-0">Loại sản phẩm</th>
                    <th class="border-0">Tên sản phẩm</th>
                    <th class="border-0">Số lượng</th>
                    <th class="border-0">Đơn giá</th>
                    <th class="border-0">Giá khuyến mãi</th>
                    <th class="border-0">Thương hiệu</th>
                    <th class="border-0">Mô tả</th>
                    <th class="border-0">Trạng thái</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($value->id); ?></td>
                        <td>
                            <p><a href="<?php echo e(route('xoa-sanpham',$value->id)); ?>">Xóa</a></p>
                            <p><a href="<?php echo e(route('sua-sanpham',$value->id)); ?>">Sửa</a></p>
                        </td>
                        <td>
                            <div class="m-r-10"><img src="source/images/product/<?php echo e($value->image); ?>" alt="user"
                                                     class="rounded"
                                                     width="80" height="60"></div>
                        </td>
                        <td>
                            <?php $__currentLoopData = $typeproduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($value->id_type == $type->id): ?>
                                    <?php echo e($type->name); ?>

                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                        <td><?php echo e($value->name); ?></td>
                        <!-- <td>id000001 </td> -->
                        <td><?php echo e($value->qty); ?></td>
                        <td><?php echo e($value->unit_price); ?></td>
                        <td><?php echo e($value->promotion_price); ?></td>
                        <td><?php echo e($value->brand); ?></td>
                        <td><?php echo e($value->description); ?></td>
                        <td><?php echo e($value->status); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shop\resources\views/admin/pageAdmin/search.blade.php ENDPATH**/ ?>