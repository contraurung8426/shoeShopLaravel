<?php $__env->startSection('list_account_content'); ?>
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="page-header">
                <h2 class="pageheader-title">Danh Sách Tài Khoản</h2>
                <div class="page-breadcrumb">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item">Tài Khoản</li>
                            <li class="breadcrumb-item active" aria-current="page"><a
                                        href="<?php echo e(route('danhsach-sanpham')); ?>">Danh Sách Tài Khoản</a></li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-12">
        <?php echo $__env->make('admin.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="row">
        <div class="table-responsive">
            <table class="table">
                <thead class="bg-light">
                <tr class="border-0">
                    <th class="border-0">#</th>
                    <th class="border-0">Thao tác</th>
                    <th class="border-0">Tên</th>
                    <th class="border-0">Email</th>
                    <th class="border-0">Địa chỉ</th>
                    <th class="border-0">Điện thoại</th>
                    <th class="border-0">Quyền</th>
                    <th class="border-0">Trạng thái</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($value->id); ?></td>
                        <td>
                            <?php if($value->locked==0): ?>
                                <p><a onclick="return ConfirmDel('Bạn muốn khóa tài khoản của <?php echo e($value->full_name); ?>?')"
                                      href="<?php echo e(route('khoa-taikhoan',$value->id)); ?>">Khóa</a></p>
                            <?php else: ?>
                                <p><a href="<?php echo e(route('khoa-taikhoan',$value->id)); ?>">Mở khóa</a></p>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($value->full_name); ?></td>
                        <td><?php echo e($value->email); ?></td>
                        <td><?php echo e($value->address); ?></td>
                        <td><?php echo e($value->phone_number); ?></td>
                        <td><?php echo e($value->premission); ?></td>
                        <td>
                            <?php if($value->status == 1): ?>
                                Đã kích hoạt
                            <?php else: ?>
                                Chưa kích hoạt
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shop\resources\views/admin/pageAdmin/list-account.blade.php ENDPATH**/ ?>