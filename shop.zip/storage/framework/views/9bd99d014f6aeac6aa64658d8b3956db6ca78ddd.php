<?php $__env->startSection('sign_in_content'); ?>
    <h2>Đăng nhập</h2>
    <h5><strong>THÔNG TIN ĐĂNG NHẬP</strong></h5>
    <form action="<?php echo e(route('dang-nhap')); ?>" method="post">
        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
        <div class="content_half float_l checkout">
            Email: (*)
            <input type="text" id="name" name="name" required style="width:300px;"/>
            <br/>
            <br/>
            Mật khẩu: (*)
            <input type="text" id="address" name="address" required style="width:300px;"/>
            <br/>
            <br/>
            <input type="submit" value="Đăng nhập">
        </div>
    </form>
    <div class="cleaner h50"></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shop\resources\views/page/signin.blade.php ENDPATH**/ ?>