<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title>Shop giày số 1 Việt Nam</title>
    <base href="<?php echo e(asset('')); ?>"/>
    <meta name="keywords" content=""/>
    <meta name="description" content=""/>
    <link href="source/css/templatemo_style.css" rel="stylesheet" type="text/css"/>
    <link href="source/css/style.css" rel="stylesheet" type="text/css"/>
    <link href="source/css/nivo-slider.css" rel="stylesheet" type="text/css" media="screen"/>

    <link rel="stylesheet" type="text/css" href="source/css/ddsmoothmenu.css"/>
    <script type="text/javascript" src="source/js/jquery.min.js"></script>
    <script type="text/javascript" src="source/js/ddsmoothmenu.js">
    </script>
    <script type="text/javascript">

        ddsmoothmenu.init({
            mainmenuid: "top_nav", //menu DIV id
            orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
            classname: 'ddsmoothmenu', //class added to menu's outer DIV
            //customtheme: ["#1c5a80", "#18374a"],
            contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
        })

    </script>

</head>

<body>

<div id="templatemo_body_wrapper">
    <div id="templatemo_wrapper">
        <?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('menubar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div id="templatemo_main">
            <div id="sidebar" class="float_l">
                <?php echo $__env->yieldContent('multi_search'); ?>
                <?php echo $__env->make('categories', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('bestsellers', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div id="content" class="float_r">
                <?php echo $__env->yieldContent('product_slider'); ?>
                <?php echo $__env->yieldContent('product_new_product'); ?>
                <?php echo $__env->yieldContent('product_sale_product'); ?>
                <?php echo $__env->yieldContent('about_content'); ?>
                <?php echo $__env->yieldContent('checkout_content'); ?>
                <?php echo $__env->yieldContent('contact_content'); ?>
                <?php echo $__env->yieldContent('faqs_content'); ?>
                <?php echo $__env->yieldContent('products_content'); ?>
                <?php echo $__env->yieldContent('producttype_content'); ?>
                <?php echo $__env->yieldContent('shoppingcart_content'); ?>
                <?php echo $__env->yieldContent('productdetail_content'); ?>
                <?php echo $__env->yieldContent('related_product_content'); ?>
                <?php echo $__env->yieldContent('search_content'); ?>
                <?php echo $__env->yieldContent('sign_up_content'); ?>
                <?php echo $__env->yieldContent('sign_in_content'); ?>
                <?php echo $__env->yieldContent('forget_password_content'); ?>
                <?php echo $__env->yieldContent('account_content'); ?>
            </div>
            <div class="cleaner"></div>
        </div> <!-- END of templatemo_main -->
        <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div> <!-- END of templatemo_wrapper -->
</div> <!-- END of templatemo_body_wrapper -->

</body>
</html><?php /**PATH C:\xampp\htdocs\shop\resources\views/master.blade.php ENDPATH**/ ?>