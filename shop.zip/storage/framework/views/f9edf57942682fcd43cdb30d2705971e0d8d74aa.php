Tên khách hàng: <?php echo e($name); ?><br>
Email khách hàng: <?php echo e($email); ?><br>
Số ĐT: <?php echo e($phone); ?><br>
Nội dung thắc mắc: <?php echo e($content); ?>

<?php /**PATH C:\xampp\htdocs\shop\resources\views/mail/blanks.blade.php ENDPATH**/ ?>