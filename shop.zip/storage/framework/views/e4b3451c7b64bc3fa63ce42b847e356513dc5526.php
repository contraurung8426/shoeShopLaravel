<?php $__env->startSection('test_ajax_content'); ?>
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    <div id="list-comment">
    <?php $__currentLoopData = $comment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="comment-content" style="border: 1px solid #725810;margin:20px 0 20px 0;">
            <p>Tên: Nguyễn Ngọc Thành</p>
            <p>Nội dung bình luận: <?php echo e($value->content); ?></p>
            <p><?php echo e($value->date); ?></p>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <input id="comment" name="comment" type="text" placeholder="Nhập nội dung bình luận"><br/><br/>
    <input id="btn-result" type="button" value="Bình luận">
    <script>
        $(document).ready(function () {
            $("#btn-result").click(function () {
                var content = $("#comment").val();
                $.get("<?php echo e(route('ajax2')); ?>", {comment_content:content}, function (data) {
                    $("#list-comment").html(data);
                });
            });
        });
    </script>
    
    
    
    
    
    
    
    
    
    
    
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shop\resources\views/admin/pageAdmin/test-ajax.blade.php ENDPATH**/ ?>