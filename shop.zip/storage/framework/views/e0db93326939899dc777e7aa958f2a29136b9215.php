<?php $__env->startSection('edit_product_content'); ?>
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="page-header">
                <h2 class="pageheader-title">Sửa Thông Tin Sản Phẩm</h2>
                <div class="page-breadcrumb">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item">Sản Phẩm</li>
                            <li class="breadcrumb-item active" aria-current="page">Sửa Thông Tin Sản Phẩm</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-12">
        <?php echo $__env->make('admin.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="row">
        <div class="card-body">
            <form action="<?php echo e(route('sua-sanpham',$product->id)); ?>" method="post" enctype="multipart/form-data">
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                <?php echo e(csrf_field()); ?>

                <div class="form-row">
                    <div class="col-xl-4 col-lg-4 col-md-12 col-sm-12 col-12 mb-2">
                        <label for="validationCustom03">Mã sản phẩm</label>
                        <input type="number" min="1" class="form-control" value="<?php echo e($product->id); ?>" readonly>
                    </div>
                </div>
                <div class="form-row">
                    <div class="col-xl-4 col-lg-4 col-md-12 col-sm-12 col-12 mb-2">
                        <label for="validationCustom03">Tên sản phẩm</label>
                        <input type="text" name="name" class="form-control" id="validationCustom03"
                               placeholder="Tên sản phẩm" value="<?php echo e($product->name); ?>"
                               required>
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-12 col-sm-12 col-12 mb-2">
                        <label for="input-select">Loại Sản Phẩm</label>
                        <select class="form-control" name="id_type" id="input-select">
                            <?php $__currentLoopData = $producttype; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($value->id == $product->id_type): ?>
                                    <option value="<?php echo e($value->id); ?>" selected><?php echo e($value->name); ?></option>
                                <?php else: ?>
                                    <option value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="form-row">
                    <div class="col-xl-4 col-lg-4 col-md-12 col-sm-12 col-12 mb-2">
                        <label for="inputText9" class="col-form-label">Số lượng</label>
                        <input id="inputText9" name="qty" type="number" class="form-control" min="1" max="100"
                               placeholder="Số lượng" value="<?php echo e($product->qty); ?>" required>
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-12 col-sm-12 col-12 mb-2">
                        <label for="inputText19" class="col-form-label">Thương hiệu</label>
                        <input type="text" name="brand" value="<?php echo e($product->brand); ?>" class="form-control"
                               placeholder="Thương hiệu">
                    </div>
                </div>
                <div class="form-row">
                    <div class="col-xl-4 col-lg-4 col-md-12 col-sm-12 col-12 mb-2">
                        <label for="inputText4" class="col-form-label">Giá tiền</label>
                        <input id="inputText4" name="unit_price" value="<?php echo e($product->unit_price); ?>" type="number"
                               class="form-control" min="0"
                               placeholder="Giá tiền"
                               required>
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-12 col-sm-12 col-12 mb-2">
                        <label for="inputText4" class="col-form-label">Giá khuyến mãi</label>
                        <input id="inputText4" name="promotion_price" value="<?php echo e($product->promotion_price); ?>"
                               type="number" class="form-control" min="0"
                               placeholder="Giá khuyến mãi">
                    </div>
                </div>
                <div class="form-row">
                    <div class="col-xl-4 col-lg-4 col-md-12 col-sm-12 col-12 mb-2">
                        <label for="exampleFormControlTextarea1">Mô tả</label>
                        <textarea class="form-control" name="description" id="exampleFormControlTextarea1"
                                  rows="3"><?php echo e($product->description); ?></textarea>
                    </div>
                </div>
                <div class="form-row">
                    <div class="col-xl-4 col-lg-4 col-md-12 col-sm-12 col-12 mb-2">
                        <input type="file" name="image" class="custom-file-input"
                               id="customFile">
                        <label class="custom-file-label" for="customFile">Thêm hình ảnh</label>
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-12 col-sm-12 col-12 mb-2">
                        <select class="form-control" name="status" id="input-select">
                            <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $tus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($product->status == $key): ?>
                                    <option value="<?php echo e($key); ?>" selected><?php echo e($tus); ?></option>
                                <?php else: ?>
                                    <option value="<?php echo e($key); ?>"><?php echo e($tus); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <button class="btn btn-primary" type="submit">Cập Nhật</button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.master-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shop\resources\views/admin/pageAdmin/edit-product.blade.php ENDPATH**/ ?>