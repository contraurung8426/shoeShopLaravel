<?php $__env->startSection('sign_up_content'); ?>
    <h2>Đăng Ký</h2>
    <?php if(count($errors)>0): ?>
        <h4 class="btn-danger">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($err); ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </h4>
    <?php endif; ?>
    <?php if(Session::has('success')): ?>
        <h4 class="btn-success">
            <?php echo e(Session::get('success')); ?>

        </h4>
    <?php endif; ?>
    <h5><strong>THÔNG TIN CÁ NHÂN</strong></h5>
    <form action="<?php echo e(route('dang-ky')); ?>" method="post">
        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
        <div class="content_half float_l checkout">
            Họ Tên: (*)
            <input type="text" id="name" value="<?php echo e(old('name')); ?>" name="name" required style="width:300px;"/>
            <br/>
            <br/>
            Mật khẩu: (*)
            <input type="password" id="address" name="password" required style="width:300px;"/>
            <br/>
            <br/>
            Nhập lại mật khẩu: (*)
            <input type="password" id="address" name="re_password" required style="width:300px;"/>
            <br/>
            <br/>
            <input type="submit" value="Đăng Ký">
            <br/>
        </div>

        <div class="content_half float_r checkout">
            E-MAIL
            <input type="email" id="email" name="email" required style="width:300px;"/>
            <br/>
            <br/>
            ĐIỆN THOẠI (*)<br/>
            <span style="font-size:10px">Để lại số điện thoại, chúng tôi có thể liên lạc</span>
            <input type="text" id="phone" value="<?php echo e(old('phone')); ?>" name="phone" style="width:300px;"/>
            <br/>
            <br/>
            Địa chỉ: (*)
            <input type="text" id="address" value="<?php echo e(old('address')); ?>" name="address" required style="width:300px;"/>
            <br/>
            <br/>
        </div>
    </form>
    <div class="cleaner h50"></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shop\resources\views/page/signup.blade.php ENDPATH**/ ?>