<?php $__env->startSection('statistical_content'); ?>
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="page-header">
                <h2 class="pageheader-title">Sản phẩm bán nhiều nhất trong quý</h2>
                <div class="page-breadcrumb">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item">Thống Kê</li>
                            <li class="breadcrumb-item active" aria-current="page"><a
                                        href="<?php echo e(route('thongke-theoquy')); ?>">Sản Phẩm Bán Nhiều Nhất Trong Quý</a>
                            </li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('admin.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row">
        <div class="card-body">
            <form action="<?php echo e(route('thongke-theoquy')); ?>" method="get">
                <div class="form-row">
                    <label for="validationCustom03" style="width: 70px;padding-top: 5px;">Nhập quý</label>
                    <div class="col-xl-1 col-lg-4 col-md-12 col-sm-12 col-12 mb-2">
                        <select class="form-control" name="quarter" id="input-select" autofocus>
                            <option value="1">Quý 1</option>
                            <option value="4">Quý 2</option>
                            <option value="7">Quý 3</option>
                            <option value="10">Quý 4</option>
                        </select>
                    </div>
                    <label for="validationCustom03" style="width: 70px;padding-top: 5px;">Nhập năm</label>
                    <div class="col-xl-1 col-lg-4 col-md-12 col-sm-12 col-12 mb-2">
                        <input type="number" min="2018" max="2050" value="2019" class="form-control" name="year" required>
                    </div>
                    <div class="col-xl-2 col-lg-4 col-md-12 col-sm-12 col-12 mb-2">
                        <input type="submit" class="form-control" value="Thống kê">
                    </div>
                </div>
            </form>

        </div>
    </div>
    <?php if(isset($product)): ?>
        <div class="row">
            <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
                <div class="card">
                    <h5 class="card-header">Sản phẩm bán chạy</h5>
                    <div class="card-body">
                        <table class="table table-hover">
                            <thead>
                            <tr>
                                <th scope="col">Mã sản phẩm</th>
                                <th scope="col">Tên Loại Sản Phẩm</th>
                                <th scope="col">Tổng số lượng bán ra</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($value->id); ?></th>
                                    <td><?php echo e($value->name); ?></td>
                                    <td><?php echo e($test[$dem++]->totalQty); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shop\resources\views/admin/pageAdmin/statistical-quarter.blade.php ENDPATH**/ ?>