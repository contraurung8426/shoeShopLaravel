<?php $__env->startSection('shoppingcart_content'); ?>
    <h1>Giỏ Hàng</h1>
    <table width="680px" cellspacing="0" cellpadding="5">
        <tr bgcolor="#ddd">
            <th width="220" align="left">Hình ảnh</th>
            <th width="180" align="left">Tên sản phẩm</th>
            <th width="100" align="center">Số lượng</th>
            <th width="60" align="right">Đơn giá</th>
            <th width="60" align="right">Tổng</th>
            <th width="90">Thao tác</th>
        </tr>
        <?php if(Session::has('cart')): ?>
            
            
            <?php $__currentLoopData = $product_cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <form action="<?php echo e(route('capnhat-gio-hang',$product['item']['id'])); ?>" method="get">
                        <td><img class="img_product" src="source/images/product/<?php echo e($product['item']['image']); ?>"
                                 alt="image 1"/></td>
                        <td><?php echo e($product['item']['name']); ?>

                        </td>
                        <td align="center"><input type="number" name="qty" min="0" max="5" value="<?php echo e($product['qty']); ?>"
                                                  style="width: 30px; text-align: right"/></td>
                        <?php if($product['item']['promotion_price']>0): ?>
                            <td align="right"><?php echo e(number_format($product['item']['promotion_price'])); ?></td>
                            <td align="right"><?php echo e(number_format($product['qty']*$product['item']['promotion_price'])); ?></td>
                        <?php else: ?>
                            <td align="right"><?php echo e(number_format($product['item']['unit_price'])); ?></td>
                            <td align="right"><?php echo e(number_format($product['qty']*$product['item']['unit_price'])); ?></td>
                        <?php endif; ?>
                        <td align="center">
                            <img src="source/images/update_icon.png" alt="update"
                                 style="width: 28px;height: 28px;"/>
                            <button type="submit" href="#"
                                    style="border: none;background-color: transparent;color: #0299aa;">Cập nhật
                            </button>
                            <a href="<?php echo e(route('xoa-gio-hang',$product['item']['id'])); ?>"><img
                                        src="source/images/remove_x.gif" alt="remove"/><br/>Xóa</a>
                        </td>
                    </form>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        <tr>
            <td colspan="3" align="right" height="30px">
            </td>
            <td colspan="1" align="right" style="background:#ddd; font-weight:bold"> T.Cộng</td>
            <?php if(Session::has('cart')): ?>
                <td align="right"
                    style="background:#ddd; font-weight:bold"><?php echo e(number_format((Session('cart')->totalPrice),0,",",".")); ?>

                    đ
                </td>
            <?php else: ?>
                <td align="right" style="background:#ddd; font-weight:bold">0đ</td>
            <?php endif; ?>
            <td style="background:#ddd; font-weight:bold"></td>
        </tr>
    </table>
    <div style="float:right; width: 215px; margin-top: 20px;">
        <p><a href="<?php echo e(route('dat-hang')); ?>">Tiến hành thanh toán</a></p>
        <p><a href="javascript:history.back()">Tiếp tục mua hàng</a></p>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shop\resources\views/page/shoppingcart.blade.php ENDPATH**/ ?>