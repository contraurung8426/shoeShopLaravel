<?php $__currentLoopData = $comment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="comment-content" style="border: 1px solid #725810;margin:20px 0 20px 0;">
        <p>Tên: Nguyễn Ngọc Thành</p>
        <p>Nội dung bình luận: <?php echo e($value->content); ?></p>
        <p><?php echo e($value->date); ?></p>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\xampp\htdocs\shop\resources\views/admin/pageAdmin/test-ajax-2.blade.php ENDPATH**/ ?>