<div class="sidebar_box"><span class="bottom"></span>
    <h3>Danh mục</h3>
    <div class="content">
        <ul class="sidebar_list">
            <?php $__currentLoopData = $danhmuc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><a href="<?php echo e(route('loai-sanpham',$value->id)); ?>"><?php echo e($value->name); ?></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</div><?php /**PATH C:\xampp\htdocs\shop\resources\views/categories.blade.php ENDPATH**/ ?>