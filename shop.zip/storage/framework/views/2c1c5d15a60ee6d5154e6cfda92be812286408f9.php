<?php $__env->startSection('search_content'); ?>
    <h1> Sản phẩm tìm kiếm</h1>
    <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="product_box">
            <h3><?php echo e($value->name); ?></h3>
            <a href="<?php echo e(route('chitiet-sanpham',$value->id)); ?>"><img class="img_product"
                                                                   src="source/images/product/<?php echo e($value->image); ?>"
                                                                   alt="Shoes 1"/></a>
            <?php if($value->promotion_price==0): ?>
                <p class="product_price"><?php echo e(number_format($value->unit_price)); ?>đ</p>
            <?php else: ?>
                <p class="product_old_price"><?php echo e(number_format($value->unit_price)); ?>đ</p>
                <p class="product_new_price"><?php echo e(number_format($value->promotion_price)); ?>đ</p>
            <?php endif; ?>
            <div class="cleaner"></div>
            <form action="<?php echo e(route('them-gio-hang')); ?>" method="post">
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                <input type="hidden" name="id" value="<?php echo e($value->id); ?>">
                <input type="number" name="qty" min="1" max="5" style="width: 30px;" required>
                <input type="submit" class="addtocart" value="Đặt hàng">
                
                <a href="<?php echo e(route('chitiet-sanpham',$value->id)); ?>" class="detail"></a>
            </form>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="cleaner"></div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shop\resources\views/page/search.blade.php ENDPATH**/ ?>