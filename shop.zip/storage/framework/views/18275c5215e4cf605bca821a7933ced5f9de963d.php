<div id="templatemo_header">
    <div id="site_title"><h1><a href="<?php echo e(route('trang-chu')); ?>">Online Shoes Store</a></h1></div>
    <div id="header_right">
        <p>
            <a href="<?php echo e(route('lien-he')); ?>">Liên Hệ</a> |
            <a href="<?php echo e(route('gio-hang')); ?>">Giỏ Hàng</a> |
            <?php if(Auth::check()): ?>
                <a href="<?php echo e(route('tt-taikhoan')); ?>">Tài Khoản</a> |
                <strong style="font-size: 15px;"><?php echo e(Auth::user()->full_name); ?> </strong><a href="<?php echo e(route('dang-xuat')); ?>">(Đăng
                    Xuất)</a>
            <?php else: ?>
                <a href="<?php echo e(route('dang-ky')); ?>">Đăng Ký</a>|
                <a href="<?php echo e(route('dang-nhap')); ?>">Đăng Nhập</a>
            <?php endif; ?>
        </p>
        <?php if(Session::has('cart')): ?>
            <p>Giỏ hàng: <strong><?php echo e(Session::get('cart')->totalQty); ?> sản phẩm</strong> ( <a
                        href="<?php echo e(route('gio-hang')); ?>">Hiển thị</a> )</p>
        <?php else: ?>
            <p>Giỏ hàng: <strong>Chưa có sản phẩm nào</strong></p>
        <?php endif; ?>
    </div>
    <div class="cleaner"></div>
</div> <!-- END of templatemo_header --><?php /**PATH C:\xampp\htdocs\shop\resources\views/header.blade.php ENDPATH**/ ?>