<?php $__env->startSection('account_content'); ?>
    <h2>Tài Khoản</h2>
    <?php if(count($errors)>0): ?>
        <h4 class="btn-danger">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($err); ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </h4>
    <?php endif; ?>
    <?php if(Session::has('success')): ?>
        <h4 class="btn-success">
            <?php echo e(Session::get('success')); ?>

        </h4>
    <?php endif; ?>
    <?php if(Session::has('error')): ?>
        <h4 class="btn-danger">
            <?php echo e(Session::get('error')); ?>

        </h4>
    <?php endif; ?>
    <h5><strong>ĐỔI MẬT KHẨU</strong></h5>
    <form action="<?php echo e(route('doi-matkhau')); ?>" method="post">
        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
        <div class="content_half float_l checkout">
            Mật khẩu cũ: (*)
            <input type="password" name="old_password"  required style="width:300px;" autofocus/>
            <br/>
            <br/>
            Mật khẩu mới: (*)
            <input type="password" name="new_password"  style="width:300px;" required/>
            <br/>
            <br/>
            Xác nhận mật khẩu (*)<br/>
            <input type="password" name="re_new_password"  style="width:300px;" required/>
            <br/>
            <br/>
            <input type="submit" value="Đổi mật khẩu">
        </div>
    </form>
    <div class="content_half float_r checkout">
        <h5><STRONG>THAO TÁC</STRONG></h5>
        <br/>
        <a href="<?php echo e(route('sua-tt-taikhoan')); ?>">Thay đổi thông tin tài khoản</a>
        <br/>
        <br/>
        <a href="<?php echo e(route('doi-matkhau')); ?>">Đổi mật khẩu</a>
    </div>
    <div class="cleaner h50"></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shop\resources\views/page/edit-password.blade.php ENDPATH**/ ?>