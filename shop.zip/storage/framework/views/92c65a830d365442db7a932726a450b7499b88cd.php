<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <base href="<?php echo e(asset('')); ?>"/>
    <link rel="stylesheet" href="source/concept-master/assets/vendor/bootstrap/css/bootstrap.min.css">
    <link href="source/concept-master/assets/vendor/fonts/circular-std/style.css" rel="stylesheet">
    <link rel="stylesheet" href="source/concept-master/assets/libs/css/style.css">
    <link rel="stylesheet" href="source/concept-master/assets/vendor/fonts/fontawesome/css/fontawesome-all.css">
    <script type="text/javascript" src="source/concept-master/assets/vendor/jquery/jquery-3.3.1.min.js"></script>
    <script type="text/javascript" src="source/concept-master/assets/libs/js/myscript.js"></script>
    <script type="text/javascript" src="source/concept-master/assets/libs/js/Chart.min.js"></script>
    <title>Trang Quản trị</title>
</head>

<body>
<div class="dashboard-main-wrapper">
    <?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.left-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="dashboard-wrapper">
        <div class="dashboard-ecommerce">
            <div class="container-fluid dashboard-content ">
                <?php echo $__env->yieldContent('multi_search'); ?>
                <?php echo $__env->yieldContent('list_product_content'); ?>
                <?php echo $__env->yieldContent('add_product_content'); ?>
                <?php echo $__env->yieldContent('edit_product_content'); ?>
                <?php echo $__env->yieldContent('del_product_content'); ?>
                <?php echo $__env->yieldContent('list_type_product_content'); ?>
                <?php echo $__env->yieldContent('add_type_product_content'); ?>
                <?php echo $__env->yieldContent('edit_type_product_content'); ?>
                <?php echo $__env->yieldContent('del_type_product_content'); ?>
                <?php echo $__env->yieldContent('search_content'); ?>
                <?php echo $__env->yieldContent('search_bill_content'); ?>
                <?php echo $__env->yieldContent('list_bill_content'); ?>
                <?php echo $__env->yieldContent('bill_detail_content'); ?>
                
                <?php echo $__env->yieldContent('statistical_content'); ?>
                <?php echo $__env->yieldContent('list_account_content'); ?>
                <?php echo $__env->yieldContent('add_account_content'); ?>
                <?php echo $__env->yieldContent('list_customer_content'); ?>
                <?php echo $__env->yieldContent('test_ajax_content'); ?>
            </div>
            <?php echo $__env->make('admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
</div>
<script src="source/concept-master/assets/vendor/jquery/jquery-3.3.1.min.js"></script>
<script src="source/concept-master/assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
<script src="source/concept-master/assets/vendor/slimscroll/jquery.slimscroll.js"></script>
<script src="source/concept-master/assets/libs/js/main-js.js"></script>
</body>

</html><?php /**PATH C:\xampp\htdocs\shop\resources\views/admin/master-admin.blade.php ENDPATH**/ ?>