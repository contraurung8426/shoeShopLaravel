<?php $__env->startSection('products_content'); ?>
    <h1> Sản phẩm</h1>
    <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="product_box">
            <h3><?php echo e($value->name); ?></h3>
            <a href="<?php echo e(route('chitiet-sanpham',$value->id)); ?>"><img class="img_product"
                                                                   src="source/images/product/<?php echo e($value->image); ?>"
                                                                   alt="Shoes 1"/></a>
            <?php if($value->promotion_price==0): ?>
                <p class="product_price"><?php echo e(number_format($value->unit_price)); ?>đ</p>
            <?php else: ?>
                <p class="product_old_price"><?php echo e(number_format($value->unit_price)); ?>đ</p>
                <p class="product_new_price"><?php echo e(number_format($value->promotion_price)); ?>đ</p>
            <?php endif; ?>
            <div class="cleaner"></div>
            <form action="<?php echo e(route('them-gio-hang')); ?>" method="post">
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                <input type="hidden" name="id" value="<?php echo e($value->id); ?>">
                <input type="number" name="qty" min="1" max="5" style="width: 30px;" required>
                <input type="submit" class="addtocart" style="font-weight: bold;color:#666666;border-radius:3px;"
                       value="Thêm vào giỏ hàng">
                
                
            </form>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="row"><?php echo e($product->links()); ?></div>
    <div class="cleaner"></div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('multi_search'); ?>
    <div class="sidebar_box"><span class="bottom"></span>
        <h3>Tìm theo yêu cầu</h3>
        <div class="content">
            <form action="<?php echo e(route('tim-kiem')); ?>" method="get">
                Loại sản phẩm: (*)
                <br/>
                <select name="id_type" style="width: 150px;">
                    <?php $__currentLoopData = $typeproduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($type->id); ?>"><?php echo e($type->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <br/>
                <br/>
                Thương hiệu: (*)
                <br/>
                <select name="brand" style="width: 150px;">
                    <?php $__currentLoopData = $brand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option><?php echo e($name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <br/>
                <br/>
                Giá từ: (*)
                <br/>
                <input type="number" step="10000" value="0" min="0" name="unit_price" required style="width:150px;"/>
                <br/>
                <br/>
                Khuyến mãi:
                <input type="checkbox" name="sale">
                <br/>
                <br/>
                <input type="submit" value="Tìm">
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shop\resources\views/page/products.blade.php ENDPATH**/ ?>