<?php $__env->startSection('search_bill_content'); ?>
    <div class="row">
        <div class="card-body">
            <form action="<?php echo e(route('danhsach-hoadon')); ?>" method="get">
                <div class="form-row">
                    <label for="validationCustom03" style="width: 70px;padding-top: 5px;">Ngày lập</label>
                    <div class="col-xl-4 col-lg-4 col-md-12 col-sm-12 col-12 mb-2">

                        <input type="date" class="form-control" name="date" required>
                    </div>
                    <div class="col-xl-1 col-lg-4 col-md-12 col-sm-12 col-12 mb-2">
                        <input type="submit" class="form-control" value="Lọc">
                    </div>
                </div>
            </form>
            <form action="<?php echo e(route('danhsach-hoadon')); ?>" method="get">
                <div class="form-row">
                    <label for="validationCustom03" style="width: 70px;padding-top: 5px;">Trạng thái</label>
                    <div class="col-xl-4 col-lg-4 col-md-12 col-sm-12 col-12 mb-2">
                        <select class="form-control" name="status" id="input-select">
                            <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($tus[0]); ?>"><?php echo e($tus[1]); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-xl-1 col-lg-4 col-md-12 col-sm-12 col-12 mb-2">
                        <input type="submit" class="form-control" value="Lọc">
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('list_bill_content'); ?>
    <?php echo $__env->make('admin.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="page-header">
                <h2 class="pageheader-title">Danh Sách Hóa Đơn</h2>
                <div class="page-breadcrumb">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item">Hóa Đơn</li>
                            <li class="breadcrumb-item active" aria-current="page"><a
                                        href="<?php echo e(route('danhsach-hoadon')); ?>">Danh Sách Hóa Đơn</a></li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="table-responsive">
            <table class="table">
                <thead class="bg-light">
                <tr class="border-0">
                    <th class="border-0">#</th>
                    <th class="border-0">Thao tác</th>
                    <th class="border-0">Khách hàng</th>
                    <th class="border-0">Ngày lập</th>
                    <th class="border-0">Tổng tiền</th>
                    <th class="border-0">Thanh toán</th>
                    <th class="border-0">Ghi chú</th>
                    <th class="border-0">Trạng thái</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $bill; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <form action="<?php echo e(route('danhsach-hoadon')); ?>" method="get">
                        <input type="hidden" name="id_bill" value="<?php echo e($value->id); ?>">
                        <tr>
                            <td><?php echo e($value->id); ?></td>
                            <td>
                                <p><a href="<?php echo e(route('chi-tiet-hoadon',$value->id)); ?>">Chi tiết</a></p>
                                <button type="submit" href="<?php echo e(route('danhsach-hoadon')); ?>"
                                        style="border: none;background-color: transparent;color: #71748d;">Sửa
                                </button>
                            </td>
                            <td>
                                <?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($cus->id == $value->id_customer): ?>
                                        <?php echo e($cus->name); ?>

                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <td><?php echo e($value->date_order); ?></td>
                            <td><?php echo e($value->total); ?></td>
                            <td><?php echo e($value->payment); ?></td>
                            <td><?php echo e($value->note); ?></td>
                            <td>
                                
                                <select style="border: none;background-color: transparent;color: #212529;"
                                        class="form-control" name="edit_status" id="input-select">
                                    <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($value->status==$tus[0]): ?>
                                            <option value="<?php echo e($tus[0]); ?>" selected><?php echo e($tus[1]); ?></option>
                                        <?php else: ?>
                                            <option value="<?php echo e($tus[0]); ?>"><?php echo e($tus[1]); ?></option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </td>
                        </tr>
                    </form>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shop\resources\views/admin/pageAdmin/list-bill.blade.php ENDPATH**/ ?>