<?php $__env->startSection('multi_search'); ?>
    <form action="<?php echo e(route('danhsach-sanpham')); ?>" method="get">
        <div class="card mb-2">
            <div class="card-header" id="headingNine">
                <h5 class="mb-0">
                    <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseNine"
                            aria-expanded="false" aria-controls="collapseNine">
                        <span class="fas mr-3 fa-angle-down"></span>Lọc
                    </button>
                </h5>
            </div>
            <div id="collapseNine" class="collapse" aria-labelledby="headingNine" data-parent="#accordion3" style="">
                <div class="form-row">
                    <div class="col-xl-4 col-lg-4 col-md-12 col-sm-12 col-12 mb-2">
                        <label for="validationCustom03">Số lượng</label>
                        <input type="number" name="qty" min="0" step="5" class="form-control" placeholder="Số lượng"
                               required>
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-12 col-sm-12 col-12 mb-2">
                        <label for="input-select">Loại Sản Phẩm</label>
                        <select class="form-control" name="id_type" id="input-select">
                            <?php $__currentLoopData = $typeproduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-12 col-sm-12 col-12 mb-2">
                        <label for="validationCustom04">Giá từ</label>
                        <input type="number" name="unit_price" min="0" step="10000" class="form-control"
                               id="validationCustom04" placeholder="Giá" required>
                    </div>
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 ">
                        <button class="btn btn-primary" type="submit">Lọc</button>
                    </div>
                </div>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('list_product_content'); ?>
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="page-header">
                <h2 class="pageheader-title">Danh Sách Sản Phẩm</h2>
                <div class="page-breadcrumb">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item">Sản Phẩm</li>
                            <li class="breadcrumb-item active" aria-current="page"><a
                                        href="<?php echo e(route('danhsach-sanpham')); ?>">Danh Sách Sản Phẩm</a></li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-12">
        <?php echo $__env->make('admin.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="row">
        <div class="table-responsive">
            <table class="table">
                <thead class="bg-light">
                <tr class="border-0">
                    <th class="border-0">#</th>
                    <th class="border-0">Thao tác</th>
                    <th class="border-0">Hình ảnh</th>
                    <th class="border-0">Loại sản phẩm</th>
                    <th class="border-0">Tên sản phẩm</th>
                    <th class="border-0">Số lượng</th>
                    <th class="border-0">Đơn giá</th>
                    <th class="border-0">Giá khuyến mãi</th>
                    <th class="border-0">Thương hiệu</th>
                    <th class="border-0">Mô tả</th>
                    <th class="border-0">Trạng thái</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($value->id); ?></td>
                        <td>
                            <p><a href="<?php echo e(route('xoa-sanpham',$value->id)); ?>">Xóa</a></p>
                            <p><a href="<?php echo e(route('sua-sanpham',$value->id)); ?>">Sửa</a></p>
                        </td>
                        <td>
                            <div class="m-r-10"><img src="source/images/product/<?php echo e($value->image); ?>" alt="user"
                                                     class="rounded"
                                                     width="80" height="60"></div>
                        </td>
                        <td>
                            <?php $__currentLoopData = $typeproduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($value->id_type == $type->id): ?>
                                    <?php echo e($type->name); ?>

                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                        <td><?php echo e($value->name); ?></td>
                        <td><?php echo e($value->qty); ?></td>
                        <td><?php echo e($value->unit_price); ?></td>
                        <td><?php echo e($value->promotion_price); ?></td>
                        <td><?php echo e($value->brand); ?></td>
                        <td><?php echo e($value->description); ?></td>
                        <td><?php echo e($status[$value->status]); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php if(isset($paginate)): ?>
        <div class="row">
            <?php echo e($product->links()); ?>

        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shop\resources\views/admin/pageAdmin/list-product.blade.php ENDPATH**/ ?>