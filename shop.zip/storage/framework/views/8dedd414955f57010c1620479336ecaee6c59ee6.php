<div id="templatemo_menubar">
    <div id="top_nav" class="ddsmoothmenu">
        <ul>
            <li><a href="<?php echo e(route('trang-chu')); ?>" class="selected">Trang chủ</a></li>
            <li><a href="<?php echo e(route('san-pham')); ?>">Sản phẩm</a>
                <ul>
                    <?php $__currentLoopData = $loaisp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e(route('loai-sanpham',$loai->id)); ?>"><?php echo e($loai->name); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </li>
            <li><a href="<?php echo e(route('gioi-thieu')); ?>">Về chúng tôi</a></li>
            <li><a href="<?php echo e(route('dieu-khoan')); ?>">FAQs</a></li>
            <li><a href="<?php echo e(route('dat-hang')); ?>">Thanh toán</a></li>
            <li><a href="<?php echo e(route('lien-he')); ?>">Liên hệ</a></li>
        </ul>
        <br style="clear: left"/>
    </div> <!-- end of ddsmoothmenu -->
    <div id="templatemo_search">
        <form action="<?php echo e(route('tim-kiem')); ?>" method="get">
            <input type="text" value=" " name="keyword" id="keyword" title="keyword" onfocus="clearText(this)"
                   onblur="clearText(this)" class="txt_field"/>
            <input type="submit" name="Search" value=" " alt="Search" id="searchbutton" title="Search" class="sub_btn"/>
        </form>
    </div>
</div> <!-- END of templatemo_menubar --><?php /**PATH C:\xampp\htdocs\shop\resources\views/menubar.blade.php ENDPATH**/ ?>