<?php $__env->startSection('forget_password_content'); ?>
    <h2>Quên mật khẩu</h2>
    <?php if(Session::has('success')): ?>
        <h4 class="btn-success">
            <?php echo e(Session::get('success')); ?>

        </h4>
    <?php endif; ?>
    <?php if(Session::has('error')): ?>
        <h4 class="btn-danger">
            <?php echo e(Session::get('error')); ?>

        </h4>
    <?php endif; ?>
    <h5><strong>Nhập địa chỉ email của bạn, chúng tôi sẽ cấp mật khẩu mới</strong></h5>
    <form action="<?php echo e(route('quen-matkhau')); ?>" method="post">
        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
        <div class="content_half float_l checkout">
            Email: (*)
            <input type="email" id="name" name="email" required style="width:300px;"/>
            <br/>
            <br/>
            <input type="submit" value="Gửi mật khẩu"></div>
    </form>
    <div class="cleaner h50"></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shop\resources\views/page/forgetpassword.blade.php ENDPATH**/ ?>