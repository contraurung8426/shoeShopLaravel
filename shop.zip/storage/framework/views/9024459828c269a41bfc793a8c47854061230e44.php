<?php $__env->startSection('account_content'); ?>
    <h2>Tài Khoản</h2>
    <h5><strong>THÔNG TIN TÀI KHOẢN</strong></h5>
    <div class="content_half float_l checkout">
        Họ Tên: (*)
        <input type="text" value="<?php echo e(Auth::user()->full_name); ?>" required style="width:300px;" readonly/>
        <br/>
        <br/>
        E-MAIL
        <input type="email" value="<?php echo e(Auth::user()->email); ?>" readonly style="width:300px;"/>
        <br/>
        <br/>
        ĐIỆN THOẠI (*)<br/>
        <input type="text" value="<?php echo e(Auth::user()->phone_number); ?>" style="width:300px;" readonly/>
        <br/>
        <br/>
        Địa chỉ: (*)
        <input type="text" value="<?php echo e(Auth::user()->address); ?>" readonly style="width:300px;"/>
    </div>
    <div class="content_half float_r checkout">
        <h5><STRONG>THAO TÁC</STRONG></h5>
        <br/>
        <a href="<?php echo e(route('sua-tt-taikhoan')); ?>">Thay đổi thông tin tài khoản</a>
        <br/>
        <br/>
        <a href="<?php echo e(route('doi-matkhau')); ?>">Đổi mật khẩu</a>
    </div>
    <div class="cleaner h50"></div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shop\resources\views/page/info-account.blade.php ENDPATH**/ ?>