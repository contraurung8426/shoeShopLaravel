<?php $__env->startSection('producttype_content'); ?>
    <h1><?php echo e($ten_loai_sp->name); ?></h1>
    <?php $__currentLoopData = $sp_theoloai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="product_box">
            <h3><?php echo e($sp->name); ?></h3>
            <a href="<?php echo e(route('chitiet-sanpham',$sp->id)); ?>"><img class="img_product"
                                                                src="source/images/product/<?php echo e($sp->image); ?>"
                                                                alt="Shoes 1"/></a>
            <?php if($sp->promotion_price==0): ?>
                <p class="product_price"><?php echo e(number_format($sp->unit_price)); ?>đ</p>
            <?php else: ?>
                <p class="product_old_price"><?php echo e(number_format($sp->unit_price)); ?>đ</p>
                <p class="product_new_price"><?php echo e(number_format($sp->promotion_price)); ?>đ</p>
            <?php endif; ?>
            <div class="cleaner"></div>
            <form action="<?php echo e(route('them-gio-hang')); ?>" method="post">
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                <input type="hidden" name="id" value="<?php echo e($sp->id); ?>">
                <input type="number" name="qty" min="1" max="5" style="width: 30px;" required>
                <input type="submit" class="addtocart" style="font-weight: bold;color:#666666;border-radius:3px;"
                       value="Thêm vào giỏ hàng">
                
                
            </form>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="cleaner"></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shop\resources\views/page/producttype.blade.php ENDPATH**/ ?>