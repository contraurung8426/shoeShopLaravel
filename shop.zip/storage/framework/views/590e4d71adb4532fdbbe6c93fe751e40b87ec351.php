<?php $__env->startSection('sign_in_content'); ?>
    <h2>Đăng nhập</h2>
    <?php if(Session::has('success')): ?>
        <h4 class="btn-success">
            <?php echo e(Session::get('success')); ?>

        </h4>
    <?php endif; ?>
    <?php if(Session::has('error')): ?>
        <h4 class="btn-danger">
            <?php echo e(Session::get('error')); ?>

        </h4>
    <?php endif; ?>
    <h5><strong>THÔNG TIN ĐĂNG NHẬP</strong></h5>
    <form action="<?php echo e(route('dang-nhap')); ?>" method="post">
        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
        <div class="content_half float_l checkout">
            Email: (*)
            <input type="email" id="name" name="email" required style="width:300px;" autofocus/>
            <br/>
            <br/>
            Mật khẩu: (*)
            <input type="password" id="address" name="password" required style="width:300px;"/>
            <br/>
            <br/>
            <input type="submit" value="Đăng nhập">
            <a href="<?php echo e(route('quen-matkhau')); ?>" style="margin-left:20px; ">Quên mật khẩu??</a>
        </div>
    </form>
    <div class="cleaner h50"></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shop\resources\views/page/SignIn.blade.php ENDPATH**/ ?>