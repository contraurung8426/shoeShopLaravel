<h2>Chào bạn {{$name}}!!</h2>
Chúng tôi nhận được yêu cầu cấp lại mật khẩu từ tài khoản của bạn và đã xử lý<br>
Mật khẩu mới của bạn là <b>{{$password}}</b><br>
Mong bạn ghi nhớ mật khẩu cận thận và đổi mật khẩu này sớm nhất có thể
<h2>Shop giày Yasuo</h2>