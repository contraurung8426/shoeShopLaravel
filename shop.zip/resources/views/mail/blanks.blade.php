Tên khách hàng: {{$name}}<br>
Email khách hàng: {{$email}}<br>
Số ĐT: {{$phone}}<br>
Nội dung thắc mắc: {{$content}}
