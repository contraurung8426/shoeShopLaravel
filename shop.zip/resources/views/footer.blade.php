<div id="templatemo_footer">
    <p><a href="#">Trang Chủ</a> | <a href="#">Sản Phẩm</a> | <a href="#">Về Chúng Tôi</a> | <a href="#">FAQs</a> | <a
                href="#">Thanh toán</a>
        | <a href="#">Liên Hệ</a>
    </p>
    Yasuo Shop Online <a href="#">Đồ Án Web PHP CDTH17C</a> <!-- Credit: www.templatemo.com -->
{{--    @if(isset($view))--}}
{{--        <p>Số lượt truy cập: {{$view->qty}} </p>--}}
{{--    @endif--}}
</div> <!-- END of templatemo_footer -->