@extends('master')
@section('faqs_content')
    <h1>FAQs</h1>
    <h5>Tôi có thể mua bao nhiêu sản phẩm trong 1 lần??</h5>
    <p>Bạn mua bao nhiêu sản phẩm cũng được hết, nhưng mỗi lần thêm vào giỏ hàng không được quá 5 sản phẩm, còn hỏi tại
        sao ư?? Bởi vì chúng tôi thích</p>
    <h5>Tôi có thể hủy đơn đặt hàng không?</h5>
    <p>Xin lỗi đơn hàng khi đã đặt là không hủy được, đơn hàng chỉ hủy khi khách không nhận hàng hoặc chúng tôi không
        thích giao</p>

    <h5>Có những phương thức thanh toán nào được sử dụng??</h5>
    <p>ATM và CTO</p>

    <h5>Tôi có thể thay đổi giỏ hàng được chứ?</h5>
    <p>Được chứ mày, mọi thứ đều oke miễn sao là không phá web chúng tôi là được</p>

    <h5>Bạn có thể hát 1 đoạn trong bài hát nào đó?</h5>
    <p>We don't talk anymore, we don't talk anymore
        We don't talk anymore, like we used to do
        We don't love anymore
        What was all of it for?
        Oh, we don't talk anymore, like we used to do
        I just heard you found the one you've been looking
        You've been looking for
        I wish I would have known that wasn't me
        'Cause even after all this time I still wonder
        Why I can't move on
        Just the way you did so easily
        Don't wanna know
        What kind of dress you're wearing tonight
        If he's holding onto you so tight
        The way I did before
        I overdosed
        Should've known your love was a game
        Now I can't get you out of my brain
        Oh, it's such a shame</p>
    <p>
        That we don't talk anymore, we don't talk anymore
        We don't talk anymore, like we used to do
        We don't love anymore
        What was all of it for?
        Oh, we don't talk anymore, like we used to do</p>


    <h5>Bạn thường đi ngủ vào lúc mấy giờ?</h5>
    <p>Tôi thường đi ngủ vào lúc 11 giờ khuya, nhưng hôm qua thì khác, tôi đi ngủ vào lúc 23 giờ. Đó là chênh lệch 1
        khoảng thời gian cực lớn khiến tôi đến sáng mới dậy được.</p>
@endsection